
import { useState } from "react";
import {
  Search,
  Rocket,
  Code,
  Trophy,
  Heart,
  BriefcaseBusiness,
  ExternalLink,
  CalendarDays,
  Lightbulb
} from "lucide-react";

const opportunities = [
  {
    title: "NASA Internships",
    type: "Internships",
    field: "STEM",
    description:
      "Explore internship programs related to science, technology, engineering, and space.",
    eligibility:
      "Requirements vary by program, age, education, and citizenship.",
    deadline: "Check the official program page.",
    url: "https://intern.nasa.gov/",
    icon: Rocket
  },
  {
    title: "MIT THINK Scholars Program",
    type: "Competitions",
    field: "STEM",
    description:
      "Explore a student research initiative supporting selected science and technology project proposals.",
    eligibility:
      "Review current eligibility and application rules before applying.",
    deadline: "Check the official program page.",
    url: "https://think.mit.edu/",
    icon: Lightbulb
  },
  {
    title: "Congressional App Challenge",
    type: "Competitions",
    field: "Technology",
    description:
      "Build an app and explore a congressional district's student app-development competition.",
    eligibility:
      "Eligibility depends on congressional district and current competition rules.",
    deadline: "Check the current competition cycle.",
    url: "https://www.congressionalappchallenge.us/",
    icon: Code
  },
  {
    title: "FIRST Robotics",
    type: "Competitions",
    field: "Engineering",
    description:
      "Discover robotics programs that combine engineering, programming, and teamwork.",
    eligibility:
      "Programs and age requirements vary. Check the official site for options.",
    deadline: "Season schedules vary.",
    url: "https://www.firstinspires.org/",
    icon: Trophy
  },
  {
    title: "Smithsonian Volunteer Opportunities",
    type: "Volunteering",
    field: "Community",
    description:
      "Explore volunteer and learning opportunities with Smithsonian museums and programs.",
    eligibility:
      "Age limits and availability vary by role and location.",
    deadline: "Check individual opportunities.",
    url: "https://www.si.edu/Volunteer",
    icon: Heart
  },
  {
    title: "CareerOneStop",
    type: "Career Exploration",
    field: "Careers",
    description:
      "Research careers, skills, training pathways, and ways to explore occupations.",
    eligibility:
      "Open career exploration resource; specific programs may have their own requirements.",
    deadline: "Self-guided resource.",
    url: "https://www.careeronestop.org/",
    icon: BriefcaseBusiness
  }
];

const types = [
  "All",
  "Internships",
  "Competitions",
  "Volunteering",
  "Career Exploration"
];

function Opportunities() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("All");

  const filtered = opportunities.filter((item) => {
    const searchableText =
      `${item.title} ${item.type} ${item.field} ${item.description} ${item.eligibility}`
        .toLowerCase();

    return (
      searchableText.includes(search.toLowerCase()) &&
      (type === "All" || item.type === type)
    );
  });

  return (
    <div>
      <header className="dashboard-header">
        <div>
          <p className="eyebrow">TAKE YOUR NEXT STEP</p>
          <h1>Opportunities</h1>
          <p className="subtitle">
            Discover ways to build skills, gain experience, and make an impact.
          </p>
        </div>
      </header>

      <div className="opportunity-highlight">
        <div className="opportunity-highlight-icon">
          <Rocket size={27} />
        </div>
        <div>
          <h2>Turn your interests into experience.</h2>
          <p>
            Explore programs, competitions, volunteering, and career resources.
            Always check official eligibility and deadlines.
          </p>
        </div>
      </div>

      <div className="search-box">
        <Search size={20} />
        <input
          type="search"
          placeholder="Search internships, coding, volunteering..."
          aria-label="Search opportunities"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
      </div>

      <div className="category-filters">
        <CalendarDays size={17} />
        {types.map((item) => (
          <button
            key={item}
            type="button"
            className={`filter-button ${type === item ? "active" : ""}`}
            aria-pressed={type === item}
            onClick={() => setType(item)}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="section-header">
        <h2>Explore opportunities</h2>
        <span className="result-count">{filtered.length} results</span>
      </div>

      <div className="resource-grid">
        {filtered.map((item) => {
          const Icon = item.icon;

          return (
            <article className="quick-card resource-card" key={item.title}>
              <div className="quick-icon">
                <Icon size={22} />
              </div>

              <span className="announcement-category">{item.type}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>

              <div className="opportunity-detail">
                <strong>Field</strong>
                <span>{item.field}</span>
              </div>

              <div className="opportunity-detail">
                <strong>Eligibility</strong>
                <span>{item.eligibility}</span>
              </div>

              <div className="opportunity-detail">
                <strong>Deadline</strong>
                <span>{item.deadline}</span>
              </div>

              <a
                className="resource-link"
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                View official resource <ExternalLink size={15} />
              </a>
            </article>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="empty-announcements">
          <Search size={28} />
          <h3>No opportunities found</h3>
          <p>Try a different keyword or category.</p>
          <button
            type="button"
            className="reset-button"
            onClick={() => {
              setSearch("");
              setType("All");
            }}
          >
            Clear filters
          </button>
        </div>
      )}

      <p className="demo-notice">
        These are starting points for research, not confirmation of open
        applications. Program availability, deadlines, and eligibility can change.
        Confirm details directly with each organization.
      </p>
    </div>
  );
}

export default Opportunities;
