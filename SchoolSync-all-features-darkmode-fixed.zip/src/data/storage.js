
const STORAGE_EVENT = "schoolsync:data-updated";

export function readStorage(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved === null ? fallback : JSON.parse(saved);
  } catch {
    return fallback;
  }
}

export function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));

    window.dispatchEvent(
      new CustomEvent(STORAGE_EVENT, {
        detail: { key, value }
      })
    );

    return true;
  } catch (error) {
    console.error(`Failed to save ${key}:`, error);
    return false;
  }
}

export function subscribeToStorage(callback) {
  const handleCustomUpdate = (event) => {
    callback(event.detail);
  };

  const handleBrowserUpdate = (event) => {
    if (event.key) {
      callback({
        key: event.key,
        value: readStorage(event.key, null)
      });
    }
  };

  window.addEventListener(STORAGE_EVENT, handleCustomUpdate);
  window.addEventListener("storage", handleBrowserUpdate);

  return () => {
    window.removeEventListener(STORAGE_EVENT, handleCustomUpdate);
    window.removeEventListener("storage", handleBrowserUpdate);
  };
}
